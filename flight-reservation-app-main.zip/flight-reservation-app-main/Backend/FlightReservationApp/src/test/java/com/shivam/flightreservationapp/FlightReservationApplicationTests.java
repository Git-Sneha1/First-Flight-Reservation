package com.shivam.flightreservationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
