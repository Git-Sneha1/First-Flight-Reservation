export default function () {
  return (
    <>
      <footer>
        <div className="container">
          <p>
            &copy; 2024 Flight Reservation System. All rights reserved. Designed
            and developed by Cloudblitz
          </p>
        </div>
      </footer>
    </>
  );
}
